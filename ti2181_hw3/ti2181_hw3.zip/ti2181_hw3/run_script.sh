# /bin/bash
echo "We are now running main file. Should take like 7-8 minutes."
python ti2181.py corpus.en corpus.de